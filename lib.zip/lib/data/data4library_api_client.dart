import 'dart:convert';

import 'package:http/http.dart' as http;

import '../config/app_config.dart';
import '../models/models.dart';

class Data4LibraryApiClient {
  Data4LibraryApiClient({http.Client? client})
    : _client = client ?? http.Client();

  final http.Client _client;

  Uri _uri(String path, Map<String, String> query) =>
      Uri.parse('${AppConfig.data4LibraryBaseUrl}/$path').replace(
        queryParameters: {
          'authKey': AppConfig.data4LibraryAuthKey,
          'format': 'json',
          ...query,
        },
      );

  Future<List<Book>> popularBooks({
    String? ageGroup,
    String? gender,
    String? genreCode,
  }) async {
    if (!AppConfig.hasApiKey) return const [];
    final uri = _uri('loanItemSrch', {
      'age': ?ageGroup,
      if (gender != null && gender != '전체') 'gender': gender,
      'kdc': ?genreCode,
    });
    final json = await _getJson(uri);
    return _extractList(json, [
      'docs',
      'doc',
      'result',
      'items',
    ]).map((e) => Book.fromJson(e, isDemo: false)).toList();
  }

  Future<List<Book>> searchBooks(String query, {int page = 1}) async {
    if (!AppConfig.hasApiKey || query.trim().isEmpty) return const [];
    final uri = _uri('srchBooks', {
      'keyword': query.trim(),
      'pageNo': '$page',
      'pageSize': '20',
    });
    final json = await _getJson(uri);
    return _extractList(json, [
      'docs',
      'doc',
      'result',
      'items',
    ]).map((e) => Book.fromJson(e, isDemo: false)).toList();
  }

  Future<List<LibraryHolding>> holdings(String isbn) async {
    if (!AppConfig.hasApiKey || isbn.trim().isEmpty) return const [];
    final uri = _uri('libSrchByBook', {'isbn': normalizeIsbn(isbn)});
    final json = await _getJson(uri);
    final now = DateTime.now();
    return _extractList(json, ['libs', 'lib', 'result', 'items']).map((e) {
      final statusText = '${e['loanAvailable'] ?? e['loanStatus'] ?? ''}';
      final status = statusText.contains('Y') || statusText.contains('가능')
          ? LoanStatus.available
          : statusText.contains('대출')
          ? LoanStatus.loaned
          : LoanStatus.checkRequired;
      return LibraryHolding(
        library: LibraryBranch.fromJson(e, isDemo: false),
        status: status,
        checkedAt: now,
      );
    }).toList();
  }

  Future<List<LibraryBranch>> libraries({String? region, String? query}) async {
    if (!AppConfig.hasApiKey) return const [];
    final uri = _uri('libSrch', {
      if (region != null && region != '전체') 'region': region,
      if (query != null && query.trim().isNotEmpty) 'libName': query.trim(),
    });
    final json = await _getJson(uri);
    return _extractList(json, [
      'libs',
      'lib',
      'result',
      'items',
    ]).map((e) => LibraryBranch.fromJson(e, isDemo: false)).toList();
  }

  Future<Map<String, dynamic>> _getJson(Uri uri) async {
    final response = await _client
        .get(uri)
        .timeout(const Duration(seconds: 10));
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw ApiException('API 응답 오류: ${response.statusCode}');
    }
    final decoded = jsonDecode(utf8.decode(response.bodyBytes));
    if (decoded is Map<String, dynamic>) return decoded;
    return <String, dynamic>{};
  }

  List<Map<String, dynamic>> _extractList(dynamic source, List<String> keys) {
    dynamic cursor = source;
    for (final key in keys) {
      if (cursor is Map && cursor[key] != null) cursor = cursor[key];
    }
    if (cursor is List) {
      return cursor
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
    }
    if (cursor is Map) {
      return cursor.values
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
    }
    return const [];
  }
}

class ApiException implements Exception {
  ApiException(this.message);
  final String message;
  @override
  String toString() => message;
}
