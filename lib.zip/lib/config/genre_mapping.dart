class GenreMapping {
  const GenreMapping({required this.label, required this.apiCode});

  final String label;
  final String apiCode;
}

const genreMappings = <GenreMapping>[
  GenreMapping(label: '문학', apiCode: '6'),
  GenreMapping(label: '인문', apiCode: '1'),
  GenreMapping(label: '사회', apiCode: '3'),
  GenreMapping(label: '과학', apiCode: '4'),
  GenreMapping(label: '역사', apiCode: '9'),
  GenreMapping(label: '예술', apiCode: '7'),
  GenreMapping(label: '종교', apiCode: '2'),
  GenreMapping(label: '기술·공학', apiCode: '5'),
  GenreMapping(label: '건강', apiCode: '5-health'),
  GenreMapping(label: '경제·경영', apiCode: '3-business'),
  GenreMapping(label: '자기계발', apiCode: '1-growth'),
  GenreMapping(label: '여행', apiCode: '9-travel'),
  GenreMapping(label: '어린이·청소년', apiCode: '8'),
];

const ageGroups = <String>[
  '10대 이하',
  '10대',
  '20대',
  '30대',
  '40대',
  '50대',
  '60대 이상',
];
const genders = <String>['전체', '남성', '여성'];
const regions = <String>[
  '서울특별시',
  '경기도',
  '인천광역시',
  '부산광역시',
  '대구광역시',
  '대전광역시',
  '광주광역시',
  '제주특별자치도',
];
