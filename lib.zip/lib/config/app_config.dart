class AppConfig {
  static const String data4LibraryAuthKey = String.fromEnvironment(
    'DATA4LIBRARY_AUTH_KEY',
  );
  static const String data4LibraryBaseUrl = 'https://data4library.kr/api';

  static bool get hasApiKey => data4LibraryAuthKey.trim().isNotEmpty;
  static bool get isDemoMode => !hasApiKey;
  static String get dataModeLabel =>
      isDemoMode ? '데모 데이터 사용 중' : '도서관 정보나루 API 연결 모드';
}
