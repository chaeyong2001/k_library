import 'dart:async';

import 'package:flutter/material.dart';

import 'config/app_config.dart';
import 'config/genre_mapping.dart';
import 'models/models.dart';
import 'repositories/library_repository.dart';
import 'services/services.dart';
import 'storage/local_store.dart';

void main() {
  runApp(const KLibraryApp());
}

class KLibraryApp extends StatelessWidget {
  const KLibraryApp({super.key});

  @override
  Widget build(BuildContext context) {
    final seed = const Color(0xFF2F6F5E);
    return MaterialApp(
      title: 'K Library',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: seed,
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF7F8F4),
        cardTheme: const CardThemeData(
          margin: EdgeInsets.zero,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(8)),
          ),
        ),
        appBarTheme: const AppBarTheme(
          centerTitle: false,
          backgroundColor: Color(0xFFF7F8F4),
          surfaceTintColor: Colors.transparent,
        ),
      ),
      home: const AppShell(),
    );
  }
}

class AppState extends ChangeNotifier {
  AppState() {
    init();
  }

  final repo = LibraryRepository();
  final store = LocalStore();
  final distance = DistanceService();
  final locator = DeviceLocationService();
  final links = ExternalLinkService();

  RecommendationPrefs prefs = const RecommendationPrefs();
  String region = '서울특별시';
  List<Book> recommendations = const [];
  List<Book> popular = const [];
  List<Book> favoriteBooks = const [];
  List<LibraryBranch> favoriteLibraries = const [];
  List<Book> recentBooks = const [];
  List<String> recentSearches = const [];
  List<LibraryBranch> libraries = const [];
  double? userLat;
  double? userLon;
  bool loading = true;
  String? message;

  Future<void> init() async {
    loading = true;
    notifyListeners();
    prefs = await store.loadRecommendationPrefs();
    region = await store.loadRegion();
    await reloadLocal();
    await Future.wait([loadRecommendations(), loadPopular(), loadLibraries()]);
    loading = false;
    notifyListeners();
  }

  Future<void> reloadLocal() async {
    favoriteBooks = await store.favoriteBooks();
    favoriteLibraries = await store.favoriteLibraries();
    recentBooks = await store.recentBooks();
    recentSearches = await store.loadRecentSearches();
    notifyListeners();
  }

  Future<void> updatePrefs(RecommendationPrefs value) async {
    prefs = value;
    await store.saveRecommendationPrefs(value);
    await loadRecommendations();
    notifyListeners();
  }

  Future<void> updateRegion(String value) async {
    region = value;
    await store.saveRegion(value);
    await loadLibraries();
    notifyListeners();
  }

  Future<void> loadRecommendations() async {
    recommendations = await repo.recommendations(prefs);
    notifyListeners();
  }

  Future<void> loadPopular({
    String? ageGroup,
    String? gender,
    String? genre,
  }) async {
    popular = await repo.popularBooks(
      ageGroup: ageGroup ?? prefs.ageGroup,
      gender: gender ?? prefs.gender,
      genre: genre,
    );
    notifyListeners();
  }

  Future<List<Book>> search(String query) async {
    await store.addRecentSearch(query);
    recentSearches = await store.loadRecentSearches();
    notifyListeners();
    return repo.searchBooks(query);
  }

  Future<List<LibraryHolding>> holdings(Book book) async {
    await store.addRecentBook(book);
    await reloadLocal();
    return repo.holdings(book.isbn);
  }

  Future<void> loadLibraries({String? query}) async {
    libraries = await repo.libraries(region: region, query: query);
    notifyListeners();
  }

  Future<void> requestLocation() async {
    final pos = await locator.currentPosition();
    userLat = pos?.latitude;
    userLon = pos?.longitude;
    message = pos == null
        ? '위치 권한 없이 지역 선택으로 사용할 수 있습니다.'
        : '현재 위치 기준 거리 계산을 적용했습니다.';
    notifyListeners();
  }

  Future<void> toggleBook(Book book) async {
    await store.toggleFavoriteBook(book);
    await reloadLocal();
  }

  Future<void> toggleLibrary(LibraryBranch library) async {
    await store.toggleFavoriteLibrary(library);
    await reloadLocal();
  }

  bool isFavoriteBook(Book book) => favoriteBooks.any((e) => e.id == book.id);
  bool isFavoriteLibrary(LibraryBranch library) =>
      favoriteLibraries.any((e) => e.id == library.id);
}

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  late final AppState state;
  int index = 0;

  @override
  void initState() {
    super.initState();
    state = AppState();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(state: state, openSearch: () => setState(() => index = 1)),
      SearchPage(state: state),
      LibrariesPage(state: state),
      ShelfPage(state: state),
      SettingsPage(state: state),
    ];
    return AnimatedBuilder(
      animation: state,
      builder: (context, _) => Scaffold(
        appBar: AppBar(
          title: const Text('K Library'),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 12),
              child: Center(child: ModePill(isDemo: AppConfig.isDemoMode)),
            ),
          ],
        ),
        body: state.loading
            ? const Center(child: CircularProgressIndicator())
            : pages[index],
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (value) => setState(() => index = value),
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.home_outlined),
              selectedIcon: Icon(Icons.home),
              label: '홈',
            ),
            NavigationDestination(icon: Icon(Icons.search), label: '검색'),
            NavigationDestination(
              icon: Icon(Icons.local_library_outlined),
              selectedIcon: Icon(Icons.local_library),
              label: '도서관',
            ),
            NavigationDestination(
              icon: Icon(Icons.bookmark_border),
              selectedIcon: Icon(Icons.bookmark),
              label: '보관함',
            ),
            NavigationDestination(
              icon: Icon(Icons.settings_outlined),
              selectedIcon: Icon(Icons.settings),
              label: '설정',
            ),
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({required this.state, required this.openSearch, super.key});
  final AppState state;
  final VoidCallback openSearch;

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async => Future.wait([
        state.loadRecommendations(),
        state.loadPopular(),
        state.loadLibraries(),
      ]),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
        children: [
          SearchLauncher(onTap: openSearch),
          const SizedBox(height: 12),
          RegionBar(state: state),
          const SizedBox(height: 18),
          SectionHeader(
            title: '맞춤 도서 추천',
            action: '조건 수정',
            onTap: () => showPrefsSheet(context, state),
          ),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              Chip(label: Text(state.prefs.ageGroup)),
              Chip(label: Text(state.prefs.gender)),
              ...state.prefs.genres.map((e) => Chip(label: Text(e))),
            ],
          ),
          const SizedBox(height: 8),
          ...state.recommendations.map(
            (book) => BookTile(book: book, state: state),
          ),
          const SizedBox(height: 18),
          SectionHeader(
            title: '인기 대출도서',
            action: '필터',
            onTap: () => showPopularFilter(context, state),
          ),
          ...state.popular
              .take(5)
              .map(
                (book) => BookTile(book: book, state: state, showRank: true),
              ),
          const SizedBox(height: 18),
          SectionHeader(
            title: '가까운 도서관',
            action: '위치 사용',
            onTap: state.requestLocation,
          ),
          ...state.libraries
              .take(3)
              .map((library) => LibraryTile(library: library, state: state)),
          if (state.recentBooks.isNotEmpty) ...[
            const SizedBox(height: 18),
            const SectionHeader(title: '최근 본 책'),
            ...state.recentBooks
                .take(3)
                .map((book) => BookTile(book: book, state: state)),
          ],
        ],
      ),
    );
  }
}

class SearchPage extends StatefulWidget {
  const SearchPage({required this.state, super.key});
  final AppState state;
  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final controller = TextEditingController();
  Timer? timer;
  List<Book> results = const [];
  bool searching = false;
  String? error;

  @override
  void dispose() {
    timer?.cancel();
    controller.dispose();
    super.dispose();
  }

  Future<void> runSearch(String query) async {
    if (query.trim().isEmpty) return;
    setState(() {
      searching = true;
      error = null;
    });
    try {
      results = await widget.state.search(query);
    } catch (_) {
      error = AppConfig.isDemoMode
          ? '데모 검색 중 오류가 발생했습니다.'
          : '네트워크 또는 인증키 상태를 확인해 주세요.';
    } finally {
      if (mounted) setState(() => searching = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
      children: [
        SearchBar(
          controller: controller,
          hintText: '책 제목, 저자, ISBN 검색',
          leading: const Icon(Icons.search),
          trailing: [
            IconButton(
              tooltip: '지우기',
              icon: const Icon(Icons.close),
              onPressed: () => setState(() {
                controller.clear();
                results = const [];
              }),
            ),
          ],
          onSubmitted: runSearch,
          onChanged: (value) {
            timer?.cancel();
            timer = Timer(
              const Duration(milliseconds: 450),
              () => runSearch(value),
            );
          },
        ),
        if (widget.state.recentSearches.isNotEmpty) ...[
          const SizedBox(height: 12),
          SectionHeader(
            title: '최근 검색어',
            action: '전체 삭제',
            onTap: () async {
              await widget.state.store.clearRecentSearches();
              await widget.state.reloadLocal();
            },
          ),
          Wrap(
            spacing: 8,
            children: widget.state.recentSearches
                .map(
                  (q) => InputChip(
                    label: Text(q),
                    onPressed: () {
                      controller.text = q;
                      runSearch(q);
                    },
                    onDeleted: () async {
                      await widget.state.store.removeRecentSearch(q);
                      await widget.state.reloadLocal();
                    },
                  ),
                )
                .toList(),
          ),
        ],
        const SizedBox(height: 16),
        if (searching)
          const Center(
            child: Padding(
              padding: EdgeInsets.all(24),
              child: CircularProgressIndicator(),
            ),
          )
        else if (error != null)
          StateBox(
            icon: Icons.error_outline,
            title: error!,
            action: '다시 시도',
            onTap: () => runSearch(controller.text),
          )
        else if (controller.text.isNotEmpty && results.isEmpty)
          const StateBox(icon: Icons.search_off, title: '검색 결과가 없습니다')
        else
          ...results.map((book) => BookTile(book: book, state: widget.state)),
      ],
    );
  }
}

class LibrariesPage extends StatefulWidget {
  const LibrariesPage({required this.state, super.key});
  final AppState state;
  @override
  State<LibrariesPage> createState() => _LibrariesPageState();
}

class _LibrariesPageState extends State<LibrariesPage> {
  final controller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
      children: [
        RegionBar(state: widget.state),
        const SizedBox(height: 10),
        SearchBar(
          controller: controller,
          hintText: '도서관명 또는 주소 검색',
          leading: const Icon(Icons.local_library_outlined),
          onChanged: (value) => widget.state.loadLibraries(query: value),
        ),
        const SizedBox(height: 10),
        FilledButton.icon(
          onPressed: widget.state.requestLocation,
          icon: const Icon(Icons.my_location),
          label: const Text('가까운 도서관 찾기'),
        ),
        const SizedBox(height: 12),
        ...widget.state.libraries.map(
          (library) => LibraryTile(library: library, state: widget.state),
        ),
      ],
    );
  }
}

class ShelfPage extends StatelessWidget {
  const ShelfPage({required this.state, super.key});
  final AppState state;
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
      children: [
        SectionHeader(
          title: '즐겨찾는 책',
          action: '전체 삭제',
          onTap: () async {
            await state.store.clearFavoriteBooks();
            await state.reloadLocal();
          },
        ),
        if (state.favoriteBooks.isEmpty)
          const StateBox(icon: Icons.bookmark_border, title: '저장한 책이 없습니다')
        else
          ...state.favoriteBooks.map((b) => BookTile(book: b, state: state)),
        const SizedBox(height: 18),
        SectionHeader(
          title: '즐겨찾는 도서관',
          action: '전체 삭제',
          onTap: () async {
            await state.store.clearFavoriteLibraries();
            await state.reloadLocal();
          },
        ),
        if (state.favoriteLibraries.isEmpty)
          const StateBox(
            icon: Icons.local_library_outlined,
            title: '저장한 도서관이 없습니다',
          )
        else
          ...state.favoriteLibraries.map(
            (l) => LibraryTile(library: l, state: state),
          ),
        const SizedBox(height: 18),
        SectionHeader(
          title: '최근 본 책',
          action: '전체 삭제',
          onTap: () async {
            await state.store.clearRecentBooks();
            await state.reloadLocal();
          },
        ),
        ...state.recentBooks.map((b) => BookTile(book: b, state: state)),
      ],
    );
  }
}

class SettingsPage extends StatelessWidget {
  const SettingsPage({required this.state, super.key});
  final AppState state;
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
      children: [
        InfoCard(
          title: 'API 연결 상태',
          body:
              '${AppConfig.dataModeLabel}\n키 입력: flutter run --dart-define=DATA4LIBRARY_AUTH_KEY=발급키',
        ),
        ListTile(
          leading: const Icon(Icons.tune),
          title: const Text('추천 조건 수정'),
          onTap: () => showPrefsSheet(context, state),
        ),
        ListTile(
          leading: const Icon(Icons.location_on_outlined),
          title: const Text('위치 권한 안내'),
          subtitle: const Text('가까운 도서관을 볼 때만 요청하며 서버에 저장하지 않습니다.'),
          onTap: state.requestLocation,
        ),
        ListTile(
          leading: const Icon(Icons.delete_sweep_outlined),
          title: const Text('데이터 캐시 삭제'),
          onTap: () async {
            await state.store.clearCaches();
            if (context.mounted) {
              ScaffoldMessenger.of(
                context,
              ).showSnackBar(const SnackBar(content: Text('캐시를 삭제했습니다.')));
            }
          },
        ),
        const InfoCard(
          title: '공공데이터 출처',
          body:
              '도서관 정보나루 Open API 연결을 위한 구조가 준비되어 있습니다. 실제 API 키 승인 전에는 데모 데이터로 표시됩니다.',
        ),
        const InfoCard(
          title: '비공식 앱 고지',
          body: '이 앱은 국립중앙도서관, 도서관 정보나루, 지방자치단체 또는 각 도서관이 직접 운영하는 공식 앱이 아닙니다.',
        ),
        const InfoCard(
          title: '개인정보 안내',
          body:
              '회원가입과 로그인을 사용하지 않습니다. 추천 조건, 즐겨찾기, 최근 검색어는 기기 내부에 저장됩니다. 위치정보는 거리 계산에만 사용합니다.',
        ),
        const InfoCard(title: '앱 버전 구조', body: '1.0.0+1 / Android 우선 1차 구현'),
      ],
    );
  }
}

class BookTile extends StatelessWidget {
  const BookTile({
    required this.book,
    required this.state,
    this.showRank = false,
    super.key,
  });
  final Book book;
  final AppState state;
  final bool showRank;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Card(
        child: ListTile(
          contentPadding: const EdgeInsets.all(12),
          leading: BookCover(rank: showRank ? book.rank : null),
          title: Text(book.title, maxLines: 2, overflow: TextOverflow.ellipsis),
          subtitle: Text(
            '${book.author}\n${book.publisher} ${book.publishYear} · ISBN ${book.isbn}\n${book.reason}',
            maxLines: 4,
            overflow: TextOverflow.ellipsis,
          ),
          isThreeLine: true,
          trailing: IconButton(
            tooltip: '즐겨찾기',
            icon: Icon(
              state.isFavoriteBook(book)
                  ? Icons.bookmark
                  : Icons.bookmark_border,
            ),
            onPressed: () => state.toggleBook(book),
          ),
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => BookDetailPage(book: book, state: state),
            ),
          ),
        ),
      ),
    );
  }
}

class BookDetailPage extends StatefulWidget {
  const BookDetailPage({required this.book, required this.state, super.key});
  final Book book;
  final AppState state;
  @override
  State<BookDetailPage> createState() => _BookDetailPageState();
}

class _BookDetailPageState extends State<BookDetailPage> {
  late Future<List<LibraryHolding>> future;
  bool onlyAvailable = true;
  @override
  void initState() {
    super.initState();
    future = widget.state.holdings(widget.book);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('책 상세')),
      body: FutureBuilder<List<LibraryHolding>>(
        future: future,
        builder: (context, snapshot) {
          final holdings = snapshot.data ?? const <LibraryHolding>[];
          final available = holdings
              .where((e) => e.status == LoanStatus.available)
              .length;
          final ranked = widget.state.distance.rankNearby(
            holdings,
            selectedRegion: widget.state.region,
            userLat: widget.state.userLat,
            userLon: widget.state.userLon,
          );
          final list = onlyAvailable ? ranked : holdings;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const BookCover(width: 84, height: 118),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.book.title,
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                        const SizedBox(height: 6),
                        Text(
                          '${widget.book.author} · ${widget.book.publisher} ${widget.book.publishYear}',
                        ),
                        Text('ISBN ${widget.book.isbn}'),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 8,
                          children: [
                            StatusChip(
                              icon: Icons.inventory_2_outlined,
                              label: '보유 ${holdings.length}곳',
                            ),
                            StatusChip(
                              icon: Icons.check_circle_outline,
                              label: '대출 가능 $available곳',
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    icon: Icon(
                      widget.state.isFavoriteBook(widget.book)
                          ? Icons.bookmark
                          : Icons.bookmark_border,
                    ),
                    onPressed: () => widget.state.toggleBook(widget.book),
                  ),
                ],
              ),
              if (widget.book.description != null)
                Padding(
                  padding: const EdgeInsets.only(top: 12),
                  child: Text(widget.book.description!),
                ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: () => setState(() => onlyAvailable = true),
                      icon: const Icon(Icons.near_me_outlined),
                      label: const Text('대출 가능 우선'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: widget.state.requestLocation,
                      icon: const Icon(Icons.my_location),
                      label: const Text('가까운 도서관'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              SegmentedButton<bool>(
                segments: const [
                  ButtonSegment(value: true, label: Text('대출 가능')),
                  ButtonSegment(value: false, label: Text('전체 보유')),
                ],
                selected: {onlyAvailable},
                onSelectionChanged: (v) =>
                    setState(() => onlyAvailable = v.first),
              ),
              const SizedBox(height: 14),
              if (snapshot.connectionState == ConnectionState.waiting)
                const Center(child: CircularProgressIndicator())
              else if (list.isEmpty)
                const StateBox(
                  icon: Icons.local_library_outlined,
                  title: '표시할 보유 도서관이 없습니다',
                )
              else
                ...list.map(
                  (h) => LibraryTile(
                    library: h.library,
                    state: widget.state,
                    holding: h,
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

class LibraryTile extends StatelessWidget {
  const LibraryTile({
    required this.library,
    required this.state,
    this.holding,
    super.key,
  });
  final LibraryBranch library;
  final AppState state;
  final LibraryHolding? holding;

  @override
  Widget build(BuildContext context) {
    final status = holding?.status;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Card(
        child: ListTile(
          contentPadding: const EdgeInsets.all(12),
          leading: CircleAvatar(
            backgroundColor: Theme.of(context).colorScheme.secondaryContainer,
            child: const Icon(Icons.local_library),
          ),
          title: Text(library.name),
          subtitle: Text(
            '${library.address}\n${library.region == state.region ? '선택 지역' : '인접 지역'} · ${state.distance.distanceLabel(library)}${status == null ? '' : ' · ${status.label}'}',
            maxLines: 3,
            overflow: TextOverflow.ellipsis,
          ),
          trailing: IconButton(
            tooltip: '즐겨찾기',
            icon: Icon(
              state.isFavoriteLibrary(library) ? Icons.star : Icons.star_border,
            ),
            onPressed: () => state.toggleLibrary(library),
          ),
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute(
              builder: (_) => LibraryDetailPage(
                library: library,
                state: state,
                holding: holding,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class LibraryDetailPage extends StatelessWidget {
  const LibraryDetailPage({
    required this.library,
    required this.state,
    this.holding,
    super.key,
  });
  final LibraryBranch library;
  final AppState state;
  final LibraryHolding? holding;

  @override
  Widget build(BuildContext context) {
    final disabled = library.homepage == null;
    return Scaffold(
      appBar: AppBar(title: const Text('도서관 상세')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(library.name, style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              if (holding != null)
                StatusChip(
                  icon: Icons.fact_check_outlined,
                  label: holding!.status.label,
                ),
              StatusChip(
                icon: Icons.place_outlined,
                label: state.distance.distanceLabel(library),
              ),
              if (library.operator != null)
                StatusChip(
                  icon: Icons.account_balance_outlined,
                  label: library.operator!,
                ),
            ],
          ),
          const SizedBox(height: 16),
          InfoCard(title: '주소', body: library.address),
          if (library.phone != null)
            InfoCard(title: '전화번호', body: library.phone!),
          if (library.homepage != null)
            InfoCard(title: '홈페이지', body: library.homepage!),
          if (library.closedInfo != null)
            InfoCard(title: '휴관·운영 정보', body: library.closedInfo!),
          if (holding != null)
            InfoCard(
              title: '최근 조회 시각',
              body: holding!.checkedAt.toLocal().toString().substring(0, 16),
            ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: disabled
                ? null
                : () => state.links.openWebsite(library.homepage),
            icon: const Icon(Icons.open_in_new),
            label: const Text('도서관 홈페이지에서 확인'),
          ),
          OutlinedButton.icon(
            onPressed: library.phone == null
                ? null
                : () => state.links.call(library.phone),
            icon: const Icon(Icons.call),
            label: const Text('전화하기'),
          ),
          OutlinedButton.icon(
            onPressed: () => state.links.directions(library),
            icon: const Icon(Icons.directions),
            label: const Text('길찾기'),
          ),
          if (disabled)
            const Padding(
              padding: EdgeInsets.only(top: 8),
              child: Text('공식 홈페이지 URL이 없어 이동 버튼을 비활성화했습니다.'),
            ),
        ],
      ),
    );
  }
}

class SearchLauncher extends StatelessWidget {
  const SearchLauncher({required this.onTap, super.key});
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(28),
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
      ),
      child: const Row(
        children: [
          Icon(Icons.search),
          SizedBox(width: 10),
          Text('책 제목, 저자, ISBN 검색'),
        ],
      ),
    ),
  );
}

class RegionBar extends StatelessWidget {
  const RegionBar({required this.state, super.key});
  final AppState state;
  @override
  Widget build(BuildContext context) => Row(
    children: [
      Expanded(
        child: DropdownButtonFormField<String>(
          initialValue: state.region,
          decoration: const InputDecoration(
            labelText: '기본 지역',
            border: OutlineInputBorder(),
          ),
          items: regions
              .map((e) => DropdownMenuItem(value: e, child: Text(e)))
              .toList(),
          onChanged: (v) {
            if (v != null) state.updateRegion(v);
          },
        ),
      ),
      const SizedBox(width: 8),
      IconButton.filledTonal(
        tooltip: '현재 위치',
        onPressed: state.requestLocation,
        icon: const Icon(Icons.my_location),
      ),
    ],
  );
}

class SectionHeader extends StatelessWidget {
  const SectionHeader({
    required this.title,
    this.action,
    this.onTap,
    super.key,
  });
  final String title;
  final String? action;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Row(
      children: [
        Expanded(
          child: Text(
            title,
            style: Theme.of(
              context,
            ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
          ),
        ),
        if (action != null) TextButton(onPressed: onTap, child: Text(action!)),
      ],
    ),
  );
}

class BookCover extends StatelessWidget {
  const BookCover({this.rank, this.width = 56, this.height = 78, super.key});
  final int? rank;
  final double width;
  final double height;
  @override
  Widget build(BuildContext context) => Container(
    width: width,
    height: height,
    decoration: BoxDecoration(
      color: const Color(0xFFE8EFE9),
      borderRadius: BorderRadius.circular(6),
      border: Border.all(color: Theme.of(context).colorScheme.outlineVariant),
    ),
    child: Stack(
      alignment: Alignment.center,
      children: [
        const Icon(Icons.menu_book, size: 28),
        if (rank != null)
          Positioned(top: 4, left: 4, child: Badge(label: Text('$rank'))),
      ],
    ),
  );
}

class ModePill extends StatelessWidget {
  const ModePill({required this.isDemo, super.key});
  final bool isDemo;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    decoration: BoxDecoration(
      color: isDemo ? const Color(0xFFFFF3CD) : const Color(0xFFDFF5E8),
      borderRadius: BorderRadius.circular(18),
    ),
    child: Text(
      isDemo ? '데모 데이터' : 'API 연결',
      style: Theme.of(context).textTheme.labelMedium,
    ),
  );
}

class StatusChip extends StatelessWidget {
  const StatusChip({required this.icon, required this.label, super.key});
  final IconData icon;
  final String label;
  @override
  Widget build(BuildContext context) =>
      Chip(avatar: Icon(icon, size: 18), label: Text(label));
}

class InfoCard extends StatelessWidget {
  const InfoCard({required this.title, required this.body, super.key});
  final String title;
  final String body;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: Theme.of(
                context,
              ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 6),
            Text(body),
          ],
        ),
      ),
    ),
  );
}

class StateBox extends StatelessWidget {
  const StateBox({
    required this.icon,
    required this.title,
    this.action,
    this.onTap,
    super.key,
  });
  final IconData icon;
  final String title;
  final String? action;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 18),
    child: Center(
      child: Column(
        children: [
          Icon(icon, size: 34),
          const SizedBox(height: 8),
          Text(title),
          if (action != null)
            TextButton(onPressed: onTap, child: Text(action!)),
        ],
      ),
    ),
  );
}

Future<void> showPrefsSheet(BuildContext context, AppState state) async {
  var age = state.prefs.ageGroup;
  var gender = state.prefs.gender;
  var selected = [...state.prefs.genres];
  await showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (context) => StatefulBuilder(
      builder: (context, setSheet) => Padding(
        padding: EdgeInsets.fromLTRB(
          16,
          0,
          16,
          MediaQuery.of(context).viewInsets.bottom + 18,
        ),
        child: ListView(
          shrinkWrap: true,
          children: [
            Text('추천 조건', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            DropdownButtonFormField(
              initialValue: age,
              decoration: const InputDecoration(labelText: '연령대'),
              items: ageGroups
                  .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                  .toList(),
              onChanged: (v) => setSheet(() => age = v!),
            ),
            const SizedBox(height: 10),
            SegmentedButton<String>(
              segments: genders
                  .map((e) => ButtonSegment(value: e, label: Text(e)))
                  .toList(),
              selected: {gender},
              onSelectionChanged: (v) => setSheet(() => gender = v.first),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: genreMappings
                  .map(
                    (g) => FilterChip(
                      label: Text(g.label),
                      selected: selected.contains(g.label),
                      onSelected: (on) => setSheet(() {
                        if (on) {
                          selected.add(g.label);
                        } else {
                          selected.remove(g.label);
                        }
                      }),
                    ),
                  )
                  .toList(),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => setSheet(() {
                      age = '30대';
                      gender = '전체';
                      selected = ['문학'];
                    }),
                    child: const Text('초기화'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: FilledButton(
                    onPressed: () {
                      state.updatePrefs(
                        RecommendationPrefs(
                          ageGroup: age,
                          gender: gender,
                          genres: selected.isEmpty ? ['문학'] : selected,
                        ),
                      );
                      Navigator.pop(context);
                    },
                    child: const Text('저장'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );
}

Future<void> showPopularFilter(BuildContext context, AppState state) async {
  var age = state.prefs.ageGroup;
  var gender = state.prefs.gender;
  String genre = '전체';
  await showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    builder: (context) => StatefulBuilder(
      builder: (context, setSheet) => Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          shrinkWrap: true,
          children: [
            Text('인기 대출도서 필터', style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 12),
            DropdownButtonFormField(
              initialValue: age,
              decoration: const InputDecoration(labelText: '연령대'),
              items: ageGroups
                  .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                  .toList(),
              onChanged: (v) => setSheet(() => age = v!),
            ),
            const SizedBox(height: 10),
            SegmentedButton<String>(
              segments: genders
                  .map((e) => ButtonSegment(value: e, label: Text(e)))
                  .toList(),
              selected: {gender},
              onSelectionChanged: (v) => setSheet(() => gender = v.first),
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField(
              initialValue: genre,
              decoration: const InputDecoration(labelText: '장르'),
              items: [
                '전체',
                ...genreMappings.map((e) => e.label),
              ].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
              onChanged: (v) => setSheet(() => genre = v!),
            ),
            const SizedBox(height: 10),
            const InfoCard(
              title: '조회 기간',
              body:
                  '빠른 선택: 최근 7일 · 최근 30일 · 최근 90일. 실제 API 연결 시 공식 파라미터에 맞춰 적용합니다.',
            ),
            FilledButton(
              onPressed: () {
                state.loadPopular(ageGroup: age, gender: gender, genre: genre);
                Navigator.pop(context);
              },
              child: const Text('적용'),
            ),
          ],
        ),
      ),
    ),
  );
}
