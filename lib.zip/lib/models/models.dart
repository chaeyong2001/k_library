import 'dart:convert';

enum LoanStatus { available, loaned, checkRequired, unavailable }

extension LoanStatusText on LoanStatus {
  String get label => switch (this) {
    LoanStatus.available => '대출 가능',
    LoanStatus.loaned => '대출 중',
    LoanStatus.checkRequired => '확인 필요',
    LoanStatus.unavailable => '정보 미제공',
  };
}

class Book {
  const Book({
    required this.id,
    required this.title,
    required this.author,
    required this.publisher,
    required this.publishYear,
    required this.isbn,
    this.coverUrl,
    this.description,
    this.rank,
    this.loanCount,
    this.genre = '문학',
    this.reason = '데모 데이터',
    this.isDemo = true,
  });

  final String id;
  final String title;
  final String author;
  final String publisher;
  final String publishYear;
  final String isbn;
  final String? coverUrl;
  final String? description;
  final int? rank;
  final int? loanCount;
  final String genre;
  final String reason;
  final bool isDemo;

  factory Book.fromJson(Map<String, dynamic> json, {bool isDemo = false}) {
    String read(List<String> keys, [String fallback = '']) {
      for (final key in keys) {
        final value = json[key];
        if (value != null && value.toString().trim().isNotEmpty) {
          return value.toString();
        }
      }
      return fallback;
    }

    int? readInt(List<String> keys) {
      for (final key in keys) {
        final value = json[key];
        if (value is int) return value;
        if (value is num) return value.toInt();
        if (value is String) {
          return int.tryParse(value.replaceAll(',', '').trim());
        }
      }
      return null;
    }

    final isbn = normalizeIsbn(read(['isbn13', 'isbn', 'isbn10']));
    return Book(
      id: read([
        'bookKey',
        'id',
      ], isbn.isEmpty ? read(['title', 'bookname'], 'unknown') : isbn),
      title: read(['title', 'bookname'], '제목 미제공'),
      author: read(['author', 'authors'], '저자 미제공'),
      publisher: read(['publisher'], '출판사 미제공'),
      publishYear: read([
        'publicationYear',
        'publication_year',
        'pubYear',
        'pubyear',
      ], ''),
      isbn: isbn,
      coverUrl: validUrl(read(['coverUrl', 'bookImageURL', 'imageUrl'])),
      description: read(['description', 'contents'], '').isEmpty
          ? null
          : read(['description', 'contents']),
      rank: readInt(['ranking', 'rank']),
      loanCount: readInt(['loan_count', 'loanCount']),
      genre: read(['genre', 'class_nm'], '분류 미제공'),
      reason: read(['reason'], isDemo ? '데모 데이터' : '공공데이터 기반'),
      isDemo: isDemo,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'author': author,
    'publisher': publisher,
    'publishYear': publishYear,
    'isbn': isbn,
    'coverUrl': coverUrl,
    'description': description,
    'rank': rank,
    'loanCount': loanCount,
    'genre': genre,
    'reason': reason,
    'isDemo': isDemo,
  };

  static Book fromEncoded(String source) =>
      Book.fromJson(jsonDecode(source) as Map<String, dynamic>, isDemo: true);
  String encode() => jsonEncode(toJson());
}

class LibraryBranch {
  const LibraryBranch({
    required this.id,
    required this.name,
    required this.address,
    required this.region,
    required this.district,
    this.phone,
    this.homepage,
    this.closedInfo,
    this.operator,
    this.latitude,
    this.longitude,
    this.distanceMeters,
    this.isDemo = true,
  });

  final String id;
  final String name;
  final String address;
  final String region;
  final String district;
  final String? phone;
  final String? homepage;
  final String? closedInfo;
  final String? operator;
  final double? latitude;
  final double? longitude;
  final double? distanceMeters;
  final bool isDemo;

  LibraryBranch copyWith({double? distanceMeters}) => LibraryBranch(
    id: id,
    name: name,
    address: address,
    region: region,
    district: district,
    phone: phone,
    homepage: homepage,
    closedInfo: closedInfo,
    operator: operator,
    latitude: latitude,
    longitude: longitude,
    distanceMeters: distanceMeters ?? this.distanceMeters,
    isDemo: isDemo,
  );

  factory LibraryBranch.fromJson(
    Map<String, dynamic> json, {
    bool isDemo = false,
  }) {
    String read(List<String> keys, [String fallback = '']) {
      for (final key in keys) {
        final value = json[key];
        if (value != null && value.toString().trim().isNotEmpty) {
          return value.toString();
        }
      }
      return fallback;
    }

    double? readDouble(List<String> keys) {
      for (final key in keys) {
        final value = json[key];
        if (value is num) return value.toDouble();
        if (value is String) return double.tryParse(value.trim());
      }
      return null;
    }

    return LibraryBranch(
      id: read(['libCode', 'id'], read(['libName', 'name'], 'library')),
      name: read(['libName', 'name'], '도서관명 미제공'),
      address: read(['address', 'addr'], '주소 미제공'),
      region: read(['region', 'sido'], '지역 미제공'),
      district: read(['district', 'sigungu'], ''),
      phone: read(['tel', 'phone'], '').isEmpty ? null : read(['tel', 'phone']),
      homepage: validUrl(read(['homepage', 'homepageUrl', 'url'])),
      closedInfo: read(['closed', 'closedInfo'], '').isEmpty
          ? null
          : read(['closed', 'closedInfo']),
      operator: read(['operator'], '').isEmpty ? null : read(['operator']),
      latitude: readDouble(['latitude', 'lat']),
      longitude: readDouble(['longitude', 'lng', 'lon']),
      isDemo: isDemo,
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'address': address,
    'region': region,
    'district': district,
    'phone': phone,
    'homepage': homepage,
    'closedInfo': closedInfo,
    'operator': operator,
    'latitude': latitude,
    'longitude': longitude,
    'isDemo': isDemo,
  };

  static LibraryBranch fromEncoded(String source) => LibraryBranch.fromJson(
    jsonDecode(source) as Map<String, dynamic>,
    isDemo: true,
  );
  String encode() => jsonEncode(toJson());
}

class LibraryHolding {
  const LibraryHolding({
    required this.library,
    required this.status,
    required this.checkedAt,
  });

  final LibraryBranch library;
  final LoanStatus status;
  final DateTime checkedAt;
}

class RecommendationPrefs {
  const RecommendationPrefs({
    this.ageGroup = '30대',
    this.gender = '전체',
    this.genres = const ['문학'],
  });

  final String ageGroup;
  final String gender;
  final List<String> genres;

  RecommendationPrefs copyWith({
    String? ageGroup,
    String? gender,
    List<String>? genres,
  }) => RecommendationPrefs(
    ageGroup: ageGroup ?? this.ageGroup,
    gender: gender ?? this.gender,
    genres: genres ?? this.genres,
  );

  Map<String, dynamic> toJson() => {
    'ageGroup': ageGroup,
    'gender': gender,
    'genres': genres,
  };

  factory RecommendationPrefs.fromJson(Map<String, dynamic> json) =>
      RecommendationPrefs(
        ageGroup: json['ageGroup']?.toString() ?? '30대',
        gender: json['gender']?.toString() ?? '전체',
        genres:
            (json['genres'] as List?)?.map((e) => e.toString()).toList() ??
            const ['문학'],
      );
}

String normalizeIsbn(String raw) => raw
    .split(RegExp(r'[,;/]'))
    .map((e) => e.replaceAll(RegExp(r'[^0-9Xx]'), ''))
    .where((e) => e.length == 10 || e.length == 13)
    .join(', ');

String? validUrl(String value) {
  final uri = Uri.tryParse(value.trim());
  if (uri == null || !(uri.isScheme('http') || uri.isScheme('https'))) {
    return null;
  }
  return uri.toString();
}
