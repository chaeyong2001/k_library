import '../config/app_config.dart';
import '../config/genre_mapping.dart';
import '../data/data4library_api_client.dart';
import '../data/demo_data_source.dart';
import '../models/models.dart';
import '../storage/local_store.dart';

class LibraryRepository {
  LibraryRepository({
    Data4LibraryApiClient? api,
    DemoDataSource? demo,
    LocalStore? store,
  }) : _api = api ?? Data4LibraryApiClient(),
       _demo = demo ?? DemoDataSource(),
       _store = store ?? LocalStore();

  final Data4LibraryApiClient _api;
  final DemoDataSource _demo;
  final LocalStore _store;
  final Map<String, Future<Object>> _inFlight = {};

  Future<List<Book>> recommendations(RecommendationPrefs prefs) async {
    if (AppConfig.isDemoMode) return _demo.recommendations(prefs);
    final result = await popularBooks(
      ageGroup: prefs.ageGroup,
      gender: prefs.gender,
      genre: prefs.genres.firstOrNull,
    );
    return result.take(5).toList();
  }

  Future<List<Book>> popularBooks({
    String? ageGroup,
    String? gender,
    String? genre,
  }) async {
    final cacheKey =
        'popular:$ageGroup:$gender:$genre:${DateTime.now().toIso8601String().substring(0, 10)}';
    return _dedupe(
      cacheKey,
      () => _store.cached<List<Book>>(
        cacheKey,
        const Duration(hours: 12),
        () async {
          if (AppConfig.isDemoMode) {
            return _demo.popular(
              ageGroup: ageGroup,
              gender: gender,
              genre: genre,
            );
          }
          final code = genreMappings
              .where((e) => e.label == genre)
              .firstOrNull
              ?.apiCode;
          final data = await _api.popularBooks(
            ageGroup: ageGroup,
            gender: gender,
            genreCode: code,
          );
          return data.isEmpty
              ? _demo.popular(ageGroup: ageGroup, gender: gender, genre: genre)
              : data;
        },
        (json) => (json as List)
            .whereType<Map>()
            .map(
              (e) => Book.fromJson(
                Map<String, dynamic>.from(e),
                isDemo: AppConfig.isDemoMode,
              ),
            )
            .toList(),
        (value) => value.map((e) => e.toJson()).toList(),
      ),
    );
  }

  Future<List<Book>> searchBooks(String query) async {
    final normalized = normalizeIsbn(query).isNotEmpty
        ? normalizeIsbn(query)
        : query.trim();
    final cacheKey = 'search:$normalized';
    return _dedupe(
      cacheKey,
      () => _store.cached<List<Book>>(
        cacheKey,
        const Duration(minutes: 20),
        () async {
          if (AppConfig.isDemoMode) return _demo.searchBooks(normalized);
          final data = await _api.searchBooks(normalized);
          return data;
        },
        (json) => (json as List)
            .whereType<Map>()
            .map(
              (e) => Book.fromJson(
                Map<String, dynamic>.from(e),
                isDemo: AppConfig.isDemoMode,
              ),
            )
            .toList(),
        (value) => value.map((e) => e.toJson()).toList(),
      ),
    );
  }

  Future<List<LibraryHolding>> holdings(String isbn) async {
    final normalized = normalizeIsbn(isbn);
    if (AppConfig.isDemoMode) return _demo.holdings(normalized);
    try {
      return await _api.holdings(normalized);
    } catch (_) {
      return const [];
    }
  }

  Future<List<LibraryBranch>> libraries({String? region, String? query}) async {
    final cacheKey = 'libraries:$region:$query';
    return _dedupe(
      cacheKey,
      () => _store.cached<List<LibraryBranch>>(
        cacheKey,
        const Duration(days: 14),
        () async {
          if (AppConfig.isDemoMode) {
            return _demo.libraryList(region: region, query: query);
          }
          final data = await _api.libraries(region: region, query: query);
          return data.isEmpty
              ? _demo.libraryList(region: region, query: query)
              : data;
        },
        (json) => (json as List)
            .whereType<Map>()
            .map(
              (e) => LibraryBranch.fromJson(
                Map<String, dynamic>.from(e),
                isDemo: AppConfig.isDemoMode,
              ),
            )
            .toList(),
        (value) => value.map((e) => e.toJson()).toList(),
      ),
    );
  }

  Future<T> _dedupe<T extends Object>(
    String key,
    Future<T> Function() loader,
  ) async {
    final existing = _inFlight[key];
    if (existing != null) return existing as Future<T>;
    final future = loader();
    _inFlight[key] = future;
    try {
      return await future;
    } finally {
      _inFlight.remove(key);
    }
  }
}
